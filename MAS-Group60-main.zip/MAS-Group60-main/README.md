# MAS-Group60
AI &amp; Multi-Agent Systems Programming Project Group 60

**Excel sheet with ideas**
https://dtudk-my.sharepoint.com/:x:/r/personal/s230416_dtu_dk/_layouts/15/Doc.aspx?sourcedoc=%7B73DFBC04-ABD4-4895-9EFA-0834B7249D04%7D&file=AI%20Proggramming%20Project%20-%20Ideas%20-%20Stucture%20%202023.xlsx&_DSL=1&action=default&mobileredirect=true
