package searchclient;

public class NotImplementedException
        extends UnsupportedOperationException
{

}
